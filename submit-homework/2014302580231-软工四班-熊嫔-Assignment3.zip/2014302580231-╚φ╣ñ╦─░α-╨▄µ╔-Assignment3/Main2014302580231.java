package PAQU;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class Main2014302580231 {
	public static void main(String[] args) {
	       MlThread2014302580231 mlThread0 = new MlThread2014302580231();  
	       Thread thread0 = new Thread(mlThread0);  
	       thread0.start();
	       MlThread2014302580231 mlThread1= new MlThread2014302580231();  
	       Thread thread1 = new Thread(mlThread1);  
	       thread1.start();
	       MlThread2014302580231 mlThread2= new MlThread2014302580231();  
	       Thread thread2 = new Thread(mlThread2);  
	       thread2.start();
	       MlThread2014302580231 mlThread3= new MlThread2014302580231();  
	       Thread thread3 = new Thread(mlThread3);  
	       thread3.start();
	       //(�������̵߳ķ�ʽ��ʵ��runnable�ӿ�)Ϊ������MlThread����Ҫ����ʵ����һ��Thread���������Լ���MlThreadʵ��
	       SingletonThread2014302580231 singletonThread =new SingletonThread2014302580231();
	       Thread t =new Thread(singletonThread);
	       t.start();
	       //�������̵߳ķ�ʽ��ʵ��runnable�ӿ�
	    	// TODO Auto-generated method stub
	}
}
	class MlThread2014302580231 implements Runnable{
	     
	    @Override
	    public void run() {
	    	//������̵߳�����ʱ��
	    	Long start2 = System.currentTimeMillis();
			System.out.println("start2:"+start2);
			BlockingQueue<Runnable> queue = new LinkedBlockingDeque<Runnable>();
			ThreadPoolExecutor executor = new ThreadPoolExecutor(3,6,1,TimeUnit.HOURS,queue);
			MlThread2014302580231 threadBody = new MlThread2014302580231();
			for(int i = 0;i<4;i++)
			{
				executor.execute(threadBody);
			}
			try { 
			    Thread.sleep(5000);                     // �߳�˯��5�룬������ʱ�䲻��ôС
			} catch (InterruptedException e) {
			    e.printStackTrace();
			}
			Long end2 = System.currentTimeMillis();
			System.out.println("end2:"+end2+" ��������"+(end2-start2));
			System.out.println("MlThread2014302580231.run()");
	        // TODO Auto-generated method stub
	    	
	         
	    }
	}
	class SingletonThread2014302580231 implements Runnable{
	     
	    @Override
	    public void run() {
	        // TODO Auto-generated method stub
	    	//���㵥�̵߳�����ʱ��
	    	
	    	Long start1 = System.currentTimeMillis();//ȡ��ʼʱ�� ��λ�Ǻ���
			System.out.println("start1:"+start1);
			for(int i = 0;i<4;i++)
			{
				System.out.println("�߳�������...");
				SingletonThread2014302580231 threadBody = new SingletonThread2014302580231();
				threadBody.run();
			}
			try { 
			    Thread.sleep(5000);                     // �߳�˯��5�룬������ʱ�䲻��ôС
			} catch (InterruptedException e) {
			    e.printStackTrace();
			}
			Long end1 = System.currentTimeMillis();
			System.out.println("end1:"+end1+" ��������"+(end1-start1));//2����
	    	System.out.println("SingletonThread.run()");
	         
	    }
	    public  Document getDocument (String url){
            try {
               return Jsoup.connect(url).get();
           } catch (IOException e) {
          e.printStackTrace();
           }
            return null;
     
}
    public static void grab()throws IOException{
    	//��ȡ��ʦ��ҳ��Ϣ
    	String[]url =new String[10];
    	url[0]="http://www.wpi.edu/academics/facultydir/mkh.html";
    	url[1]="http://www.wpi.edu/academics/facultydir/cls.html";
    	url[2]="http://www.wpi.edu/academics/facultydir/jb7.html";
    	url[3]="http://www.wpi.edu/academics/facultydir/db5.html";
    	url[4]=	"http://www.wpi.edu/academics/facultydir/dcb.html";
    	url[5]="http://www.wpi.edu/academics/facultydir/sch.html";
    	url[6]="http://www.wpi.edu/academics/facultydir/mxg.html";
    	url[7]="http://www.wpi.edu/academics/facultydir/nth.html";
    	url[8]="http://www.wpi.edu/academics/datascience/cr.html";
        url[9]="http://www.wpi.edu/academics/facultydir/cr1.html";
    	for(int i=0;i<url.length;i++){
    	SingletonThread2014302580231 n =new SingletonThread2014302580231();
    	Document doc = n.getDocument(url[i]);
    	//��ȡĿ����Ϣ���ڵ�HTML����
    	Elements elements1 = doc.select("body");
    	// ��ȡ������Ϣ
    	Elements elements2 = elements1.select("h2");
    	String name = elements2.get(0).text();
        System.out.println(name);
        //��ȡ�о�������Ϣ
        Elements elements3 = elements1.select("h1");
        String area = elements3.get(0).text();
        System.out.println(area);
        //��ȡ�绰��Ϣ
        Elements elements4 = elements1.select("div.contactinfo ��p��br");
        String telephone = elements4.get(2).text();
        System.out.println(telephone);
    	}
    }
    public void writeFile(){
    	 String aa = "area";
    	 String bb ="name";
    	 String cc ="telephone";
    	 FileWriter fw = null;
    	 BufferedWriter br = null;
    	    try {
    	        fw = new FileWriter("C:/teacherlist.txt");
    	        //����һ���������д����
    	        br = new BufferedWriter(fw);
    	        br.write(aa);
    	        br.write(bb);
    	        br.write(cc);
    	        //�ѻ����е�����ȫ���Ƶ��ļ���
    	        br.flush();
    	    } catch (IOException e) {
    	        e.printStackTrace();
    	    }
    	    //���һ���ǻ�����Դ
    	    finally{
    	        try {
    	            br.close();
    	            fw.close();
    	        } catch (IOException e) {
    	            br = null;
    	            fw = null;
    	        }
    	    }
    	  
		
		
    }
  
		
	   
		} 


	

