import java.io.IOException;
import java.sql.SQLException;


public class Main2014302580207 {

	public static void main(String[] args) throws IOException, SQLException {
		// TODO �Զ����ɵķ������
		
		//���߳�
		long starTime1 = System.currentTimeMillis();
		SingleThread s = new SingleThread();
		long endTime1 = System.currentTimeMillis();
		long time1 = endTime1 - starTime1;
		System.out.println("���̺߳�ʱ��"+time1);
		
		//���߳�
		long starTime2 = System.currentTimeMillis();
		MultiThread t = new MultiThread();
		
		Thread t1 = new Thread(t);
		Thread t2 = new Thread(t);
		Thread t3 = new Thread(t);
		Thread t4 = new Thread(t);
		Thread t5 = new Thread(t);
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		t5.start();
		long endTime2 = System.currentTimeMillis();
		long time2 = endTime2 - starTime2;
		
		
		System.out.println("���̺߳�ʱ��"+time2);
		
	}

}
